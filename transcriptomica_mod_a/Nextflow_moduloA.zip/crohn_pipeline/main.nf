#!/usr/bin/env nextflow
nextflow.enable.dsl=2

params.reads = "data/*.fastq.gz"
params.outdir = "results"

workflow {

    reads_ch = Channel.fromPath(params.reads)

    // Flujo completo
    falco_out = falco(reads_ch)
    fastp_out = fastp(falco_out)
    hisat2_out = hisat2(fastp_out)
    counts_out = featureCounts(hisat2_out)
    deseq2_out = deseq2_like(counts_out)
}

//////////////////////////////////////////////////////////
// FALCO dummy
process falco {
    tag "$reads"
    publishDir "${params.outdir}/falco", mode: 'copy'

    input:
    path reads

    output:
    path "falco_${reads.getName()}"

    script:
    """
    echo "Simulating Falco for ${reads.getName()}"
    cp ${reads} falco_${reads.getName()}
    """
}

//////////////////////////////////////////////////////////
// FASTP dummy
process fastp {
    tag "$reads"
    publishDir "${params.outdir}/fastp", mode: 'copy'

    input:
    path reads

    output:
    path "clean_${reads.getName()}"

    script:
    """
    echo "Simulating fastp for ${reads.getName()}"
    cp ${reads} clean_${reads.getName()}
    """
}

//////////////////////////////////////////////////////////
// HISAT2 dummy
process hisat2 {
    tag "$reads"
    publishDir "${params.outdir}/hisat2", mode: 'copy'

    input:
    path reads

    output:
    path "aligned_${reads.getName()}.bam"

    script:
    """
    echo "Simulating Hisat2 alignment for ${reads.getName()}"
    cp ${reads} aligned_${reads.getName()}.bam
    """
}

//////////////////////////////////////////////////////////
// FEATURECOUNTS dummy
process featureCounts {
    tag "$bam"
    publishDir "${params.outdir}/counts", mode: 'copy'

    input:
    path bam

    output:
    path "counts_${bam.getName()}.txt"

    script:
    """
    echo -e "GeneID\tSample1" > counts_${bam.getName()}.txt
    echo -e "gene1\t42" >> counts_${bam.getName()}.txt
    echo "Simulating featureCounts"
    """
}

//////////////////////////////////////////////////////////
// DESEQ2-like dummy (Python)
process deseq2_like {
    tag "$counts"
    publishDir "${params.outdir}/deseq2", mode: 'copy'

    input:
    path counts

    output:
    path "deseq2_results_${counts.getName()}.txt"

    script:
    """
    echo -e "gene\tlog2FoldChange\tpadj" > deseq2_results_${counts.getName()}.txt
    echo -e "gene1\t1.5\t0.05" >> deseq2_results_${counts.getName()}.txt
    echo "Simulating DESeq2 analysis"
    """
}
