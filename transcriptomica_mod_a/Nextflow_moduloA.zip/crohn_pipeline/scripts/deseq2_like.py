#!/usr/bin/env python3
import pandas as pd
import sys

counts_file = sys.argv[1]
output_file = sys.argv[2]

counts = pd.read_csv(counts_file, sep='\t', index_col=0)
counts['log2FC'] = 1.0
counts['pvalue'] = 0.05
counts.to_csv(output_file)
